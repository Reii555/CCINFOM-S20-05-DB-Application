DROP DATABASE IF EXISTS delivery_pickup_db;
CREATE DATABASE delivery_pickup_db;
USE delivery_pickup_db;